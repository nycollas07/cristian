package org.firstinspires.ftc.teamcode;

import com.acmerobotics.dashboard.config.Config;
import com.qualcomm.robotcore.hardware.DcMotorSimple;

/*
 * Some additional constants for testing.
 */
@Config
public class SampleConstants {
    public static DcMotorSimple.Direction DIR = DcMotorSimple.Direction.FORWARD;
    public static boolean FF_ENABLED = false;
}
