// .prettierrc.js
module.exports = {
  singleQuote: true,
  printWidth: 80,
  trailingComma: 'all',
};
