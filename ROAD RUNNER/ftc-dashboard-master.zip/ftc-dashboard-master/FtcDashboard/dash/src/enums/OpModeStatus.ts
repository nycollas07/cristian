export const OpModeStatus = {
  INIT: 'INIT',
  RUNNING: 'RUNNING',
  STOPPED: 'STOPPED',
} as const;

export default OpModeStatus;
