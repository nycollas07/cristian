---
layout: default
---

# Competition Use

The **dashboard cannot be used during matches** pursuant to RS09 (2021-2022 Game Manual Part 1). To prevent accidental connections, you should use the "Disable Dashboard" menu item or provided op mode during gameplay. 

Dashboard use may be permitted in the pits. Keep other teams in mind and limit bandwidth usage, especially high-framerate camera streams.
