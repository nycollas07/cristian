package com.noahbres.meepmeep.core.entity

interface EntityEventListener {
    fun onAddToEntityList()
    fun onRemoveFromEntityList()
}