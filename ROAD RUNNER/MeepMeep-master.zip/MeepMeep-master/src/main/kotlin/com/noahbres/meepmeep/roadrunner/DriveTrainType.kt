package com.noahbres.meepmeep.roadrunner

enum class DriveTrainType {
    MECANUM,
    TANK
}
