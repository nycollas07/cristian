package com.noahbres.meepmeep.roadrunner.trajectorysequence;

public class EmptySequenceException extends RuntimeException { }
